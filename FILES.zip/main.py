# Importing necessary libraries
import os
import pickle
import numpy as np
import cv2
import face_recognition
import cvzone
import firebase_admin
from firebase_admin import credentials
from firebase_admin import db
from firebase_admin import storage
from datetime import datetime
import time
    
# Firebase credentials and initialization
cred = credentials.Certificate("faceid-detector-firebase-adminsdk-eglyv-d375170d8e.json")
firebase_admin.initialize_app(cred, {
    'databaseURL': "https://faceid-detector-default-rtdb.firebaseio.com/",
    'storageBucket': "faceid-detector.appspot.com"
})

bucket = storage.bucket()

# Initializing camera
cap = cv2.VideoCapture(0)
cap.set(3, 640)
cap.set(4, 480)

# Loading the background image
imgBackground = cv2.imread('Resources/background.png')

# Importing mode images into a list
folderModePath = 'Resources/Modes'
modePathList = os.listdir(folderModePath)
imgModeList = []
for path in modePathList:
    imgModeList.append(cv2.imread(os.path.join(folderModePath, path)))

# Loading the encoding file
print("Loading Encode File ...")
file = open('EncodeFile.p', 'rb')
encodeListKnownWithIds = pickle.load(file)
file.close()
encodeListKnown, studentIds = encodeListKnownWithIds
print("Encode File Loaded")

# Initializing variables
modeType = 0
counter = 0
id = -1
imgStudent = []

# Main loop for face recognition
while True:
    success, img = cap.read()

    imgS = cv2.resize(img, (0, 0), None, 0.25, 0.25)
    imgS = cv2.cvtColor(imgS, cv2.COLOR_BGR2RGB)

    faceCurFrame = face_recognition.face_locations(imgS)
    encodeCurFrame = face_recognition.face_encodings(imgS, faceCurFrame)

    imgBackground[162:162 + 480, 55:55 + 640] = img
    imgBackground[44:44 + 633, 808:808 + 414] = imgModeList[modeType]

    if faceCurFrame:
            # Loop through detected faces to check for matches with known faces
        for encodeFace, faceLoc in zip(encodeCurFrame, faceCurFrame):
            # Compare the current face encoding with the known face encodings
            matches = face_recognition.compare_faces(encodeListKnown, encodeFace)
            # Calculate the face distances between the current face and known faces
            faceDis = face_recognition.face_distance(encodeListKnown, encodeFace)

            # Find the index of the minimum distance
            matchIndex = np.argmin(faceDis)

            # If a match is found, update variables accordingly
            if matches[matchIndex]:
                # Extract the coordinates of the face bounding box
                y1, x2, y2, x1 = faceLoc
                y1, x2, y2, x1 = y1 * 4, x2 * 4, y2 * 4, x1 * 4
                # Adjust the coordinates for the overlay on the background image
                bbox = 55 + x1, 162 + y1, x2 - x1, y2 - y1
                # Draw a corner rectangle around the detected face on the background image
                imgBackground = cvzone.cornerRect(imgBackground, bbox, rt=0)
                # Retrieve the ID of the matched student
                id = studentIds[matchIndex]
                # If it's the first frame of detection, display loading message and set modeType
                if counter == 0:
                    cvzone.putTextRect(imgBackground, "Loading", (275, 400))
                    cv2.imshow("Face Attendance", imgBackground)
                    cv2.waitKey(1)
                    counter = 1
                    modeType = 1

        # Handling the case when counter is not 0
        if counter != 0:
            # Executing when counter is 1
            if counter == 1:
                # Retrieving student information from the database using student ID
                studentInfo = db.reference(f'Students/{id}').get()
                # Retrieving student image from storage using student ID
                blob = bucket.get_blob(f'Images/{id}.jpg')
                array = np.frombuffer(blob.download_as_string(), np.uint8)
                imgStudent = cv2.imdecode(array, cv2.COLOR_BGRA2BGR)
                # Updating attendance data
                datetimeObject = datetime.strptime(studentInfo['last_attendance_time'], "%Y-%m-%d %H:%M:%S")
                secondsElapsed = (datetime.now() - datetimeObject).total_seconds()
                if secondsElapsed > 30:
                    ref = db.reference(f'Students/{id}')
                    studentInfo['total_attendance'] += 1
                    ref.child('total_attendance').set(studentInfo['total_attendance'])
                    ref.child('last_attendance_time').set(datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
                else:
                    # If the last attendance was taken within 30 seconds, set modeType to 3 'allaqachon lingan' and reset counter
                    modeType = 3
                    counter = 0
                    imgBackground[44:44 + 633, 808:808 + 414] = imgModeList[modeType]

            # Executing when modeType is not 3
            if modeType != 3:
                # Adjusting modeType based on counter value
                if 10 < counter < 230:
                    modeType = 2 # information about students

                # Displaying appropriate image mode on the background
                imgBackground[44:44 + 633, 808:808 + 414] = imgModeList[modeType]

                # Executing when counter is less than or equal to 10
                if counter <= 10:
                    # Displaying student information on the background image
                    cv2.putText(imgBackground, str(studentInfo['total_attendance']), (861, 125),
                                cv2.FONT_HERSHEY_COMPLEX, 1, (255, 255, 255), 1)
                    cv2.putText(imgBackground, str(studentInfo['major']), (1006, 550),
                                cv2.FONT_HERSHEY_COMPLEX, 0.5, (255, 255, 255), 1)
                    cv2.putText(imgBackground, str(id), (1006, 493),
                                cv2.FONT_HERSHEY_COMPLEX, 0.5, (255, 255, 255), 1)
                    cv2.putText(imgBackground, str(studentInfo['standing']), (910, 625),
                                cv2.FONT_HERSHEY_COMPLEX, 0.6, (100, 100, 100), 1)
                    cv2.putText(imgBackground, str(studentInfo['year']), (1025, 625),
                                cv2.FONT_HERSHEY_COMPLEX, 0.6, (100, 100, 100), 1)
                    cv2.putText(imgBackground, str(studentInfo['starting_year']), (1125, 625),
                                cv2.FONT_HERSHEY_COMPLEX, 0.6, (100, 100, 100), 1)

                    # Displaying student name on the background image
                    cv2.putText(imgBackground, str(studentInfo['name']), (808, 445),
                                cv2.FONT_HERSHEY_COMPLEX, 1, (50, 50, 50), 1)

                # Resizing and displaying student image on the background image
                imgStudent_resized = cv2.resize(imgStudent, (216, 216))
                imgBackground[175:175 + 216, 909:909 + 216] = imgStudent_resized

                # Incrementing the counter
                counter += 1

                # Resetting the counter and modeType when counter exceeds 20
                if counter >= 20:
                    counter = 0
                    modeType = 0
                    studentInfo = []
                    imgStudent = []
                    imgBackground[44:44 + 633, 808:808 + 414] = imgModeList[modeType]

                # Adding a delay for smooth execution
                time.sleep(1)

        # Executing when counter is 0
        else:
            modeType = 0
            counter = 0


    cv2.imshow("Face Attendance", imgBackground)
    cv2.waitKey(1)
