import firebase_admin
from firebase_admin import credentials
from firebase_admin import db

cred = credentials.Certificate("faceid-detector-firebase-adminsdk-eglyv-d375170d8e.json")
firebase_admin.initialize_app(cred, {
    'databaseURL': "https://faceid-detector-default-rtdb.firebaseio.com/"
})

ref = db.reference('Students')

data = {
    "111112":
        {
            "name": "IZZATBEK NASRIEV",
            "major": "ECONOMICS",
            "starting_year": 2023,
            "total_attendance": 0,
            "standing": "4",
            "year": 1,
            "last_attendance_time": "2022-12-11 00:54:34"
        },
    "111122":
        {
            "name": "Zokirov Abdulboriy",
            "major": "Economics",
            "starting_year": 2023,
            "total_attendance": 0,
            "standing": "5",
            "year": 1,
            "last_attendance_time": "2022-12-11 00:54:34"
        },
    "111222":
        {
            "name": "Toxirova Gulasal",
            "major": "Physics",
            "starting_year": 2020,
            "total_attendance": 7,
            "standing": "3",
            "year": 2,
            "last_attendance_time": "2022-12-11 00:54:34"
        },
    "112233":
        {
            "name": "zokirov Javohir",
            "major": "math",
            "starting_year": 2020,
            "total_attendance": 7,
            "standing": "3",
            "year": 2,
            "last_attendance_time": "2022-12-11 00:54:34"
        },
    "123456":
        {
            "name": "Usmonov Saidakbar",
            "major": "turizm",
            "starting_year": 2022,
            "total_attendance": 7,
            "standing": "4",
            "year": 2,
            "last_attendance_time": "2022-12-11 00:54:34"
        },
    "321123":
        {
            "name": "Mironshox Inomjonov",
            "major": "computer sciense",
            "starting_year": 2021,
            "total_attendance": 7,
            "standing": "3",
            "year": 2,
            "last_attendance_time": "2022-12-11 00:54:34"
        },
    
    "963852":
        {
            "name": "Elon Musk",
            "major": "Physics",
            "starting_year": 2020,
            "total_attendance": 7,
            "standing": "3",
            "year": 2,
            "last_attendance_time": "2022-12-11 00:54:34"
        },
    "000001":
        {
            "name": "Xurshidbek",
            "major": "dasturiy enjinering ",
            "starting_year": 2020,
            "total_attendance": 7,
            "standing": "3",
            "year": 2,
            "last_attendance_time": "2022-12-11 00:54:34"
        }
        
}

for key, value in data.items():
    ref.child(key).set(value)

